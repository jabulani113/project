interface EmailNotification {
  to: string;
  subject: string;
  message: string;
  timestamp: string;
  userInfo?: {
    name: string;
    email: string;
    accountType: string;
  };
}

export const sendEmailNotification = async (notification: EmailNotification) => {
  try {
    // Log the notification for development
    console.log('Email Notification:', notification);
    
    // For production, integrate with your email service provider
    // Examples: SendGrid, AWS SES, Nodemailer, etc.
    
    // Example API call structure:
    // const response = await fetch('/api/send-email', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(notification)
    // });
    
    // Simulate email sending delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return { success: true, message: 'Email notification sent successfully' };
  } catch (error) {
    console.error('Failed to send email notification:', error);
    return { success: false, message: 'Failed to send email notification' };
  }
};

export const createWelcomeEmail = (userEmail: string, userName: string) => ({
  to: userEmail,
  subject: 'Welcome to InvestPro - Account Created Successfully',
  message: `
    Dear ${userName},

    Welcome to InvestPro! Your account has been successfully created.

    Account Details:
    - Email: ${userEmail}
    - Registration Date: ${new Date().toLocaleString()}
    - Account Status: Active

    Next Steps:
    1. Complete face verification to access your dashboard
    2. Make your first deposit to start trading
    3. Explore our investment portfolios

    If you have any questions, our customer support team is available 24/7.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createLoginEmail = (userEmail: string, userName: string) => ({
  to: userEmail,
  subject: 'InvestPro - Account Login Notification',
  message: `
    Dear ${userName},

    You have successfully logged into your InvestPro account.

    Login Details:
    - Date: ${new Date().toLocaleString()}
    - IP Address: [System will capture actual IP]
    - Device: [System will capture device info]

    If this wasn't you, please contact our security team immediately.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createDepositEmail = (userEmail: string, userName: string, amount: string) => ({
  to: userEmail,
  subject: 'InvestPro - Deposit Request Submitted',
  message: `
    Dear ${userName},

    Your deposit request has been submitted successfully.

    Deposit Details:
    - Amount: $${amount}
    - Date: ${new Date().toLocaleString()}
    - Status: Pending Processing

    Please follow the payment instructions sent separately. Your funds will be credited within 24 hours of payment confirmation.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createWithdrawalEmail = (userEmail: string, userName: string, amount: string) => ({
  to: userEmail,
  subject: 'InvestPro - Withdrawal Request Submitted',
  message: `
    Dear ${userName},

    Your withdrawal request has been submitted successfully.

    Withdrawal Details:
    - Amount: $${amount}
    - Date: ${new Date().toLocaleString()}
    - Status: Under Review

    Your request will be processed within 24-48 hours. You will receive confirmation once the transfer is completed.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createSignalPurchaseEmail = (userEmail: string, userName: string, signalName: string, price: number) => ({
  to: userEmail,
  subject: 'InvestPro - Trading Signal Package Purchased',
  message: `
    Dear ${userName},

    You have successfully purchased a trading signal package.

    Purchase Details:
    - Package: ${signalName}
    - Price: $${price}
    - Date: ${new Date().toLocaleString()}
    - Duration: 30 Days

    You will receive your first signals within the next hour. Check your email for access instructions.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createRemotePinEmail = (userEmail: string, userName: string, pinName: string, price: number) => ({
  to: userEmail,
  subject: 'InvestPro - Remote PIN Purchased',
  message: `
    Dear ${userName},

    You have successfully purchased a Remote PIN.

    Purchase Details:
    - PIN Type: ${pinName}
    - Price: $${price}
    - Date: ${new Date().toLocaleString()}

    Your Remote PIN will be activated within 15 minutes. Check your email for setup instructions.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createAccountUpgradeEmail = (userEmail: string, userName: string, upgradeName: string) => ({
  to: userEmail,
  subject: 'InvestPro - Account Upgraded Successfully',
  message: `
    Dear ${userName},

    Your account has been successfully upgraded.

    Upgrade Details:
    - New Account Type: ${upgradeName}
    - Date: ${new Date().toLocaleString()}
    - Status: Active

    Your new features are now active. Enjoy your enhanced trading experience!

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createIDVerificationEmail = (userEmail: string, userName: string, status: 'submitted' | 'approved' | 'rejected') => {
  const statusMessages = {
    submitted: {
      subject: 'ID Verification Submitted - InvestPro',
      message: `
        Dear ${userName},

        Your ID verification has been submitted successfully.

        Verification Details:
        - Submission Date: ${new Date().toLocaleString()}
        - Status: Under Review

        Our verification team will review your documents within 24-48 hours. You will receive an email notification once the verification is complete.

        Important Notes:
        - Keep your ID documents safe and accessible
        - Do not share your ID details with unauthorized persons
        - Contact support if you need to update your submission

        Thank you for helping us maintain a secure trading environment.

        Best regards,
        The InvestPro Verification Team
      `
    },
    approved: {
      subject: 'ID Verification Approved - InvestPro',
      message: `
        Dear ${userName},

        Congratulations! Your ID verification has been approved.

        Verification Details:
        - Approval Date: ${new Date().toLocaleString()}
        - Status: Verified ✓
        - Account Access: Full Access Granted

        You now have full access to all InvestPro features including:
        - Unlimited deposits and withdrawals
        - Advanced trading tools
        - Premium customer support
        - All investment portfolios

        Thank you for completing the verification process.

        Best regards,
        The InvestPro Team
      `
    },
    rejected: {
      subject: 'ID Verification Requires Attention - InvestPro',
      message: `
        Dear ${userName},

        We were unable to approve your ID verification at this time.

        Common reasons for rejection:
        - Blurry or unclear images
        - Expired identification documents
        - Incomplete information visible
        - Document type not accepted

        Next Steps:
        1. Review the verification guidelines
        2. Ensure your ID is current and valid
        3. Take clear, well-lit photos
        4. Resubmit your verification

        If you need assistance, please contact our support team.

        Best regards,
        The InvestPro Verification Team
      `
    }
  };

  return {
    to: userEmail,
    subject: statusMessages[status].subject,
    message: statusMessages[status].message,
    timestamp: new Date().toISOString()
  };
};

export const createFaceVerificationEmail = (userEmail: string, userName: string) => ({
  to: userEmail,
  subject: 'InvestPro - Face Verification Completed',
  message: `
    Dear ${userName},

    Your face verification has been completed successfully.

    Verification Details:
    - Date: ${new Date().toLocaleString()}
    - Status: Verified
    - Account Access: Full Access Granted

    You can now access all features of your InvestPro dashboard.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createSendMoneyEmail = (senderEmail: string, senderName: string, recipientName: string, amount: string, message: string) => ({
  to: senderEmail,
  subject: 'InvestPro - Money Transfer Sent',
  message: `
    Dear ${senderName},

    You have successfully sent money to another InvestPro user.

    Transfer Details:
    - Recipient: ${recipientName}
    - Amount: $${amount}
    - Date: ${new Date().toLocaleString()}
    - Status: Completed
    ${message ? `- Message: "${message}"` : ''}

    The transfer has been completed instantly and the recipient has been notified.

    Your updated account balance will be reflected in your dashboard.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});

export const createReceiveMoneyEmail = (recipientEmail: string, recipientName: string, senderName: string, amount: string, message: string) => ({
  to: recipientEmail,
  subject: 'InvestPro - Money Received',
  message: `
    Dear ${recipientName},

    You have received money from another InvestPro user.

    Transfer Details:
    - From: ${senderName}
    - Amount: $${amount}
    - Date: ${new Date().toLocaleString()}
    - Status: Completed
    ${message ? `- Message: "${message}"` : ''}

    The money has been added to your account balance instantly.

    You can view your updated balance in your dashboard.

    Best regards,
    The InvestPro Team
  `,
  timestamp: new Date().toISOString()
});