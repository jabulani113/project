export interface User {
  id: string;
  email: string;
  name: string;
  balance: number;
  totalDeposit: number;
  totalProfit: number;
  bonus: number;
  withdrawalStatus: 'pending' | 'approved' | 'completed' | 'none';
  accountType: 'basic' | 'premium' | 'vip';
  faceVerified: boolean;
  idVerified: boolean;
  idVerificationStatus: 'none' | 'pending' | 'approved' | 'rejected';
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  date: string;
}

export interface Signal {
  id: string;
  name: string;
  price: number;
  description: string;
  accuracy: string;
}

export interface RemotePin {
  id: string;
  name: string;
  price: number;
  description: string;
  duration: string;
}

export interface AccountUpgrade {
  id: string;
  name: string;
  price: number;
  features: string[];
  currentPlan?: boolean;
}