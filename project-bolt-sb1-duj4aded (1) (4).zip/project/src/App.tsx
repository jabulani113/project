import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import DashboardLayout from './components/Dashboard/DashboardLayout';
import LandingPage from './components/LandingPage';
import FaceVerification from './components/Auth/FaceVerification';

const AppContent = () => {
  const { isAuthenticated, user } = useAuth();

  // Interface 1: Full Dashboard for verified users
  if (isAuthenticated && user?.faceVerified) {
    return <DashboardLayout />;
  }

  // Interface 2: Face verification for authenticated but unverified users
  if (isAuthenticated && !user?.faceVerified) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <FaceVerification />
      </div>
    );
  }

  // Interface 3: Public landing page for non-authenticated users
  return <LandingPage interfaceType="public" />;
};

const App = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;