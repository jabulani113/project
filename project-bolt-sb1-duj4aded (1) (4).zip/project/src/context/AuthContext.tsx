import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User } from '../types';
import { 
  sendEmailNotification, 
  createWelcomeEmail, 
  createLoginEmail, 
  createFaceVerificationEmail 
} from '../utils/emailService';

interface AuthContextType {
  user: User | null;
  login: (usernameOrEmail: string, password: string) => Promise<boolean>;
  register: (username: string, name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  updateFaceVerification: (verified: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = async (usernameOrEmail: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock user data
    const mockUser: User = {
      id: '1',
      email: usernameOrEmail.includes('@') ? usernameOrEmail : 'user@example.com',
      name: 'John Doe',
      balance: 0.00,
      totalDeposit: 0.00,
      totalProfit: 8750.25,
      bonus: 0.00,
      withdrawalStatus: 'none',
      accountType: 'premium',
      faceVerified: false,
      idVerified: false,
      idVerificationStatus: 'none'
    };
    
    setUser(mockUser);
    
    // Send login notification email
    try {
      const loginEmail = createLoginEmail(mockUser.email, mockUser.name);
      await sendEmailNotification(loginEmail);
    } catch (error) {
      console.error('Failed to send login notification:', error);
    }
    
    return true;
  };

  const register = async (username: string, name: string, email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: '1',
      email,
      name,
      balance: 0,
      totalDeposit: 0.00,
      totalProfit: 0,
      bonus: 0.00,
      withdrawalStatus: 'none',
      accountType: 'basic',
      faceVerified: false,
      idVerified: false,
      idVerificationStatus: 'none'
    };
    
    setUser(mockUser);
    
    // Send welcome email notification
    try {
      const welcomeEmail = createWelcomeEmail(email, name);
      await sendEmailNotification(welcomeEmail);
    } catch (error) {
      console.error('Failed to send welcome email:', error);
    }
    
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateFaceVerification = (verified: boolean) => {
    if (user) {
      setUser({ ...user, faceVerified: verified });
      
      // Send face verification email
      if (verified) {
        try {
          const verificationEmail = createFaceVerificationEmail(user.email, user.name);
          sendEmailNotification(verificationEmail);
        } catch (error) {
          console.error('Failed to send face verification email:', error);
        }
      }
    }
  };

  const value = {
    user,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    updateFaceVerification
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};