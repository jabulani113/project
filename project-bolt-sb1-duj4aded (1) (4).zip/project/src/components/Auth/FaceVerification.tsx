import React, { useState, useRef, useEffect } from 'react';
import { Camera, CheckCircle, AlertCircle, RotateCcw, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const FaceVerification = () => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationStep, setVerificationStep] = useState<'instructions' | 'camera' | 'processing' | 'success' | 'failed'>('instructions');
  const [error, setError] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const { updateFaceVerification } = useAuth();

  const startCamera = async () => {
    try {
      // Request camera permissions explicitly
      const permissions = await navigator.permissions.query({ name: 'camera' as PermissionName });
      
      if (permissions.state === 'denied') {
        setError('Camera access denied. Please enable camera permissions in your browser settings and refresh the page.');
        return;
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: 640, 
          height: 480,
          facingMode: 'user',
          aspectRatio: 4/3
        } 
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        // Ensure video plays
        videoRef.current.play().catch(console.error);
      }
      setVerificationStep('camera');
      setError('');
    } catch (err) {
      console.error('Camera access error:', err);
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError') {
          setError('Camera access denied. Please allow camera access and try again.');
        } else if (err.name === 'NotFoundError') {
          setError('No camera found. Please ensure you have a camera connected.');
        } else if (err.name === 'NotReadableError') {
          setError('Camera is already in use by another application.');
        } else {
          setError('Unable to access camera. Please check your camera permissions and try again.');
        }
      } else {
        setError('Unable to access camera. Please ensure camera permissions are granted.');
      }
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const captureAndVerify = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setIsVerifying(true);
    setVerificationStep('processing');

    // Capture image from video
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');
    
    if (context) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0);
    }

    // Simulate face verification process
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Simulate successful verification (90% success rate for demo)
      const isSuccess = Math.random() > 0.1;
      
      if (isSuccess) {
        setVerificationStep('success');
        updateFaceVerification(true);
        stopCamera();
      } else {
        setVerificationStep('failed');
        setError('Face verification failed. Please ensure your face is clearly visible and try again.');
      }
    } catch (err) {
      setVerificationStep('failed');
      setError('Verification process failed. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  const retryVerification = () => {
    setVerificationStep('instructions');
    setError('');
    stopCamera();
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  if (verificationStep === 'success') {
    return (
      <div className="max-w-md mx-auto bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
        <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-8 w-8 text-green-400" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-4">Verification Successful!</h2>
        <p className="text-slate-300 mb-6">
          Your face has been successfully verified. You can now access your dashboard.
        </p>
        <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
          <p className="text-green-400 text-sm">
            Redirecting to dashboard...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-slate-800 rounded-2xl p-8 border border-slate-700">
      <div className="text-center mb-8">
        <Camera className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-2">Face Verification Required</h2>
        <p className="text-slate-300">
          For security purposes, please complete face verification to access your dashboard.
        </p>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-red-400" />
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        </div>
      )}

      {verificationStep === 'instructions' && (
        <div className="space-y-6">
          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Verification Instructions</h3>
            <div className="space-y-3 text-sm text-slate-300">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">1</div>
                <span>Position your face clearly in front of the camera</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">2</div>
                <span>Ensure good lighting and remove any face coverings</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">3</div>
                <span>Look directly at the camera and remain still</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">4</div>
                <span>Click "Capture & Verify" when ready</span>
              </div>
            </div>
          </div>

          <button
            onClick={startCamera}
            className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors flex items-center justify-center gap-2"
          >
            <Camera className="h-5 w-5" />
            Start Camera
          </button>
        </div>
      )}

      {verificationStep === 'camera' && (
        <div className="space-y-6">
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
            <p className="text-green-400 text-sm">
              ✓ Camera access granted. Position your face within the oval guide and click "Capture & Verify" when ready.
            </p>
          </div>
          
          <div className="relative bg-slate-700 rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 border-4 border-yellow-400/50 rounded-lg pointer-events-none">
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-64 border-2 border-yellow-400 rounded-full"></div>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-lg text-sm">
                Position your face in the oval
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={captureAndVerify}
              disabled={isVerifying}
              className="flex-1 bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isVerifying ? 'Verifying...' : 'Capture & Verify'}
            </button>
            <button
              onClick={retryVerification}
              className="px-6 py-3 border border-slate-600 text-slate-300 rounded-lg hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {verificationStep === 'processing' && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <User className="h-8 w-8 text-yellow-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Processing Verification</h3>
          <p className="text-slate-300 mb-6">
            Please wait while we verify your identity...
          </p>
          <div className="w-full bg-slate-700 rounded-full h-2">
            <div className="bg-yellow-400 h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
          </div>
        </div>
      )}

      {verificationStep === 'failed' && (
        <div className="text-center space-y-6">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="h-8 w-8 text-red-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white mb-2">Verification Failed</h3>
            <p className="text-slate-300">
              We couldn't verify your identity. Please try again.
            </p>
          </div>
          <button
            onClick={retryVerification}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors flex items-center justify-center gap-2 mx-auto"
          >
            <RotateCcw className="h-5 w-5" />
            Try Again
          </button>
        </div>
      )}

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default FaceVerification;