import React from 'react';
import { ArrowRight, Shield, TrendingUp, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface HeroProps {
  onOpenAuth?: (mode: 'login' | 'register') => void;
}

const Hero: React.FC<HeroProps> = ({ onOpenAuth }) => {
  const { isAuthenticated } = useAuth();

  return (
    <section id="home" className="pt-20 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Grow Your <span className="text-yellow-400">Wealth</span> with Smart Investments
            </h1>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              Join thousands of investors who trust InvestPro to build their financial future. 
              Our expert-managed portfolios deliver consistent returns with minimal risk.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              {isAuthenticated ? (
                <button 
                  onClick={() => window.location.href = '#dashboard'}
                  className="bg-yellow-400 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-yellow-300 transition-all transform hover:scale-105 flex items-center justify-center gap-2"
                >
                  Go to Dashboard
                  <ArrowRight className="h-5 w-5" />
                </button>
              ) : (
                <button 
                  onClick={() => onOpenAuth?.('register')}
                  className="bg-yellow-400 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-yellow-300 transition-all transform hover:scale-105 flex items-center justify-center gap-2"
                >
                  Start Trading Today
                  <ArrowRight className="h-5 w-5" />
                </button>
              )}
              <button className="border-2 border-slate-300 text-slate-100 px-8 py-4 rounded-lg font-semibold hover:bg-slate-700 transition-colors">
                View Our Performance
              </button>
            </div>
            <div className="grid grid-cols-3 gap-8">
              <div className="flex items-center gap-3">
                <Shield className="h-8 w-8 text-yellow-400" />
                <div>
                  <div className="font-semibold">SEC Regulated</div>
                  <div className="text-sm text-blue-200">Fully Compliant</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <TrendingUp className="h-8 w-8 text-yellow-400" />
                <div>
                  <div className="font-semibold">14.8% Returns</div>
                  <div className="text-sm text-slate-200">Average Annual</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Users className="h-8 w-8 text-yellow-400" />
                <div>
                  <div className="font-semibold">52K+ Traders</div>
                  <div className="text-sm text-slate-200">Trust Our Platform</div>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://images.pexels.com/photos/7567529/pexels-photo-7567529.jpeg?auto=compress&cs=tinysrgb&w=800" 
              alt="Investment Growth"
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -top-4 -right-4 bg-yellow-400 text-blue-900 p-4 rounded-xl font-bold">
              <div className="text-2xl">+24.5%</div>
              <div className="text-sm">This Quarter</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;