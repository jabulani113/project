import React, { useState } from 'react';
import { Crown, Star, CheckCircle, Zap } from 'lucide-react';
import { AccountUpgrade } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createAccountUpgradeEmail } from '../../utils/emailService';

const AccountUpgrading = () => {
  const [selectedUpgrade, setSelectedUpgrade] = useState<string | null>(null);
  const [isPurchased, setIsPurchased] = useState(false);
  const { user } = useAuth();

  const upgrades: AccountUpgrade[] = [
    {
      id: '1',
      name: 'Basic Account',
      price: 0,
      features: [
        'Basic trading features',
        'Standard customer support',
        'Basic market analysis',
        '1 withdrawal per month',
        'Email notifications'
      ],
      currentPlan: user?.accountType === 'basic'
    },
    {
      id: '2',
      name: 'Premium Account',
      price: 299,
      features: [
        'Advanced trading tools',
        'Priority customer support',
        'Advanced market analysis',
        '5 withdrawals per month',
        'SMS + Email notifications',
        'Personal account manager',
        'Reduced trading fees'
      ],
      currentPlan: user?.accountType === 'premium'
    },
    {
      id: '3',
      name: 'VIP Account',
      price: 999,
      features: [
        'All premium features',
        'VIP customer support',
        'Professional market analysis',
        'Unlimited withdrawals',
        'All notification types',
        'Dedicated account manager',
        'Lowest trading fees',
        'Exclusive trading signals',
        'Priority trade execution',
        'Custom trading strategies'
      ],
      currentPlan: user?.accountType === 'vip'
    }
  ];

  const handleUpgrade = async (upgradeId: string) => {
    const upgrade = upgrades.find(u => u.id === upgradeId);
    
    // Send account upgrade notification email
    if (user && upgrade) {
      try {
        const upgradeEmail = createAccountUpgradeEmail(user.email, user.name, upgrade.name);
        await sendEmailNotification(upgradeEmail);
      } catch (error) {
        console.error('Failed to send account upgrade notification:', error);
      }
    }
    
    setSelectedUpgrade(upgradeId);
    setIsPurchased(true);
  };

  if (isPurchased && selectedUpgrade) {
    const upgrade = upgrades.find(u => u.id === selectedUpgrade);
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Account Upgraded!</h2>
          <p className="text-slate-300 mb-6">
            Your account has been successfully upgraded to <span className="font-bold text-yellow-400">{upgrade?.name}</span>.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Your new features are now active. Enjoy your enhanced trading experience!
            </p>
          </div>
          <button
            onClick={() => setIsPurchased(false)}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Explore Features
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <Crown className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">Account Upgrading</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          Unlock advanced features and benefits by upgrading your account. Choose the plan that best fits your trading needs.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {upgrades.map((upgrade, index) => (
          <div 
            key={upgrade.id} 
            className={`bg-slate-800 rounded-2xl p-6 border transition-colors relative ${
              upgrade.currentPlan 
                ? 'border-yellow-400 bg-yellow-400/5' 
                : 'border-slate-700 hover:border-slate-600'
            } ${index === 1 ? 'transform scale-105' : ''}`}
          >
            {upgrade.currentPlan && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="bg-yellow-400 text-slate-900 px-4 py-1 rounded-full text-sm font-bold">
                  Current Plan
                </div>
              </div>
            )}
            
            {index === 1 && (
              <div className="absolute -top-3 right-4">
                <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                  Most Popular
                </div>
              </div>
            )}

            <div className="flex items-center justify-between mb-4">
              {index === 0 && <Star className="h-8 w-8 text-slate-400" />}
              {index === 1 && <Crown className="h-8 w-8 text-yellow-400" />}
              {index === 2 && <Zap className="h-8 w-8 text-purple-400" />}
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-3">{upgrade.name}</h3>
            
            <div className="text-center mb-6">
              <div className="text-4xl font-bold text-white mb-1">
                {upgrade.price === 0 ? 'Free' : `$${upgrade.price}`}
              </div>
              {upgrade.price > 0 && (
                <div className="text-slate-400 text-sm">one-time upgrade fee</div>
              )}
            </div>
            
            <div className="space-y-3 mb-8">
              {upgrade.features.map((feature, featureIndex) => (
                <div key={featureIndex} className="flex items-center gap-3">
                  <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0" />
                  <span className="text-slate-300 text-sm">{feature}</span>
                </div>
              ))}
            </div>
            
            <button
              onClick={() => handleUpgrade(upgrade.id)}
              disabled={upgrade.currentPlan}
              className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                upgrade.currentPlan
                  ? 'bg-slate-600 text-slate-400 cursor-not-allowed'
                  : upgrade.price === 0
                  ? 'bg-slate-600 text-white hover:bg-slate-500'
                  : 'bg-yellow-400 text-slate-900 hover:bg-yellow-300'
              }`}
            >
              {upgrade.currentPlan ? 'Current Plan' : upgrade.price === 0 ? 'Current Plan' : 'Upgrade Now'}
            </button>
          </div>
        ))}
      </div>

      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <h3 className="text-2xl font-bold text-white mb-6">Why Upgrade?</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Enhanced trading capabilities</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Priority customer support</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Advanced market analysis</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Reduced fees and commissions</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Exclusive trading opportunities</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Personal account management</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountUpgrading;