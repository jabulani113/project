import React, { useState } from 'react';
import { DollarSign, Mail, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createDepositEmail } from '../../utils/emailService';

const Deposit = () => {
  const [amount, setAmount] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Send deposit notification email
    if (user) {
      try {
        const depositEmail = createDepositEmail(user.email, user.name, amount);
        await sendEmailNotification(depositEmail);
      } catch (error) {
        console.error('Failed to send deposit notification:', error);
      }
    }
    
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Deposit Request Submitted</h2>
          <p className="text-slate-300 mb-6">
            Your deposit request for <span className="font-bold text-yellow-400">${amount}</span> has been submitted successfully.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Please email our customer support team for account details and payment instructions.
            </p>
          </div>
          <button
            onClick={() => setIsSubmitted(false)}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Make Another Deposit
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <div className="text-center mb-8">
          <DollarSign className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-2">Make a Deposit</h2>
          <p className="text-slate-300">Add funds to your trading account</p>
        </div>

        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-8">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-yellow-400 font-medium mb-1">Important Notice</p>
              <p className="text-yellow-300 text-sm">
                After submitting your deposit request, please email our customer support team for detailed account information and payment instructions.
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Deposit Amount (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                placeholder="Enter amount"
                min="10"
                step="0.01"
                required
              />
            </div>
            <p className="text-slate-400 text-sm mt-2">Minimum deposit: $10.00</p>
          </div>

          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Quick Amount Selection</h3>
            <div className="grid grid-cols-3 gap-3">
              {['100', '500', '1000', '2500', '5000', '10000'].map((quickAmount) => (
                <button
                  key={quickAmount}
                  type="button"
                  onClick={() => setAmount(quickAmount)}
                  className="py-2 px-4 rounded-lg border border-slate-600 text-slate-300 hover:border-yellow-400 hover:text-yellow-400 transition-colors"
                >
                  ${quickAmount}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Next Steps</h3>
            <div className="space-y-3 text-sm text-slate-300">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">1</div>
                <span>Submit your deposit request below</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">2</div>
                <span>Email customer support for account details</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">3</div>
                <span>Complete payment using provided details</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-yellow-400 text-slate-900 rounded-full flex items-center justify-center text-xs font-bold">4</div>
                <span>Funds will be credited within 24 hours</span>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Submit Deposit Request
          </button>
        </form>
      </div>
    </div>
  );
};

export default Deposit;