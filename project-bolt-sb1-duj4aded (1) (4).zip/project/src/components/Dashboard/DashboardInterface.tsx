import React from 'react';
import { Shield, TrendingUp, Users, DollarSign, CreditCard, Crown } from 'lucide-react';
import DashboardLayout from './DashboardLayout';

const DashboardInterface = () => {
  return (
    <div className="min-h-screen bg-slate-900">
      {/* Dashboard Interface Header */}
      <div className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <TrendingUp className="h-8 w-8 text-yellow-400" />
            <div>
              <h1 className="text-xl font-bold text-white">InvestPro Dashboard</h1>
              <p className="text-slate-400 text-sm">Authenticated User Interface</p>
            </div>
            <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
              SECURE
            </span>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-400" />
              <span className="text-green-400 text-sm font-medium">Verified Account</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Features Overview */}
      <div className="p-6 bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center space-x-3">
                <DollarSign className="h-6 w-6 text-green-400" />
                <div>
                  <div className="text-white font-semibold">Trading</div>
                  <div className="text-slate-400 text-xs">Live Markets</div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center space-x-3">
                <CreditCard className="h-6 w-6 text-blue-400" />
                <div>
                  <div className="text-white font-semibold">Transactions</div>
                  <div className="text-slate-400 text-xs">Secure Payments</div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center space-x-3">
                <Crown className="h-6 w-6 text-yellow-400" />
                <div>
                  <div className="text-white font-semibold">Premium</div>
                  <div className="text-slate-400 text-xs">Advanced Tools</div>
                </div>
              </div>
            </div>
            
            <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
              <div className="flex items-center space-x-3">
                <Users className="h-6 w-6 text-purple-400" />
                <div>
                  <div className="text-white font-semibold">Support</div>
                  <div className="text-slate-400 text-xs">24/7 Available</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Dashboard Layout */}
      <DashboardLayout />
    </div>
  );
};

export default DashboardInterface;