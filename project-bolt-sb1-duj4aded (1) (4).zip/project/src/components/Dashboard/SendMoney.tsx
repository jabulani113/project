import React, { useState } from 'react';
import { Send, User, DollarSign, CheckCircle, AlertCircle, Search } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createSendMoneyEmail, createReceiveMoneyEmail } from '../../utils/emailService';

const SendMoney = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    recipientUsername: '',
    amount: '',
    message: ''
  });
  const [recipientFound, setRecipientFound] = useState<{
    username: string;
    name: string;
    email: string;
  } | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear recipient when username changes
    if (name === 'recipientUsername') {
      setRecipientFound(null);
      setError('');
    }
  };

  const searchRecipient = async () => {
    if (!formData.recipientUsername.trim()) {
      setError('Please enter a username to search');
      return;
    }

    setIsSearching(true);
    setError('');

    try {
      // Simulate API call to search for user
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock user search (in production, this would be an actual API call)
      const mockUsers = [
        { username: 'john_trader', name: 'John Smith', email: 'john@example.com' },
        { username: 'sarah_investor', name: 'Sarah Johnson', email: 'sarah@example.com' },
        { username: 'mike_crypto', name: 'Mike Chen', email: 'mike@example.com' },
        { username: 'emma_forex', name: 'Emma Rodriguez', email: 'emma@example.com' }
      ];

      const foundUser = mockUsers.find(u => 
        u.username.toLowerCase() === formData.recipientUsername.toLowerCase()
      );

      if (foundUser) {
        setRecipientFound(foundUser);
      } else {
        setError('User not found. Please check the username and try again.');
      }
    } catch (err) {
      setError('Error searching for user. Please try again.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!recipientFound) {
      setError('Please search and select a recipient first');
      return;
    }

    if (!user) {
      setError('User not authenticated');
      return;
    }

    const amount = parseFloat(formData.amount);
    if (amount <= 0) {
      setError('Amount must be greater than 0');
      return;
    }

    if (amount > user.balance) {
      setError('Insufficient balance for this transfer');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Simulate API call for money transfer
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Send email notifications
      const senderEmail = createSendMoneyEmail(
        user.email,
        user.name,
        recipientFound.name,
        formData.amount,
        formData.message
      );
      
      const recipientEmail = createReceiveMoneyEmail(
        recipientFound.email,
        recipientFound.name,
        user.name,
        formData.amount,
        formData.message
      );

      await Promise.all([
        sendEmailNotification(senderEmail),
        sendEmailNotification(recipientEmail)
      ]);

      setIsSubmitted(true);
    } catch (err) {
      setError('Transfer failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isSubmitted && recipientFound) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Money Sent Successfully!</h2>
          <p className="text-slate-300 mb-6">
            You have successfully sent <span className="font-bold text-yellow-400">${formData.amount}</span> to{' '}
            <span className="font-bold text-blue-400">{recipientFound.name}</span> (@{recipientFound.username}).
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Both you and the recipient have been notified via email. The transfer is now complete.
            </p>
          </div>
          <button
            onClick={() => {
              setIsSubmitted(false);
              setFormData({ recipientUsername: '', amount: '', message: '' });
              setRecipientFound(null);
            }}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Send Another Transfer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <div className="text-center mb-8">
          <Send className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-2">Send Money to Friend</h2>
          <p className="text-slate-300">
            Transfer money to other registered users on the platform
          </p>
        </div>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-8">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-blue-400 font-medium mb-1">Transfer Information</p>
              <p className="text-blue-300 text-sm">
                You can send money to any registered user on InvestPro using their username. 
                Both parties will receive email notifications for the transaction.
              </p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-400" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Recipient Search */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Recipient Username
            </label>
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  name="recipientUsername"
                  value={formData.recipientUsername}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter recipient's username"
                  required
                />
              </div>
              <button
                type="button"
                onClick={searchRecipient}
                disabled={isSearching || !formData.recipientUsername.trim()}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isSearching ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4" />
                    Search
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Recipient Found */}
          {recipientFound && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <div className="font-semibold text-white">{recipientFound.name}</div>
                  <div className="text-green-400 text-sm">@{recipientFound.username}</div>
                </div>
                <CheckCircle className="h-5 w-5 text-green-400 ml-auto" />
              </div>
            </div>
          )}

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Amount (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
              <input
                type="number"
                name="amount"
                value={formData.amount}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                placeholder="Enter amount"
                min="0.01"
                step="0.01"
                required
              />
            </div>
            {user && (
              <p className="text-slate-400 text-sm mt-2">
                Available balance: ${user.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            )}
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Message (Optional)
            </label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleInputChange}
              rows={3}
              className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors resize-none"
              placeholder="Add a message for the recipient..."
            />
          </div>

          {/* Transfer Summary */}
          {recipientFound && formData.amount && (
            <div className="bg-slate-700 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Transfer Summary</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-300">Recipient</span>
                  <span className="text-white font-medium">{recipientFound.name} (@{recipientFound.username})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Amount</span>
                  <span className="text-white font-medium">${formData.amount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Transfer Fee</span>
                  <span className="text-green-400 font-medium">Free</span>
                </div>
                <div className="border-t border-slate-600 pt-3 flex justify-between">
                  <span className="text-slate-300">Total</span>
                  <span className="text-yellow-400 font-bold">${formData.amount}</span>
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading || !recipientFound || !formData.amount}
            className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
                Processing Transfer...
              </>
            ) : (
              <>
                <Send className="h-5 w-5" />
                Send Money
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-slate-400 text-sm">
            Transfers are instant and secure. Both parties will receive email confirmations.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SendMoney;