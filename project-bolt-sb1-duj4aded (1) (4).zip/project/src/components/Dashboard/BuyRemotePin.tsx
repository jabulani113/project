import React, { useState } from 'react';
import { Shield, Clock, CheckCircle, Smartphone } from 'lucide-react';
import { RemotePin } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createRemotePinEmail } from '../../utils/emailService';

const BuyRemotePin = () => {
  const [selectedPin, setSelectedPin] = useState<string | null>(null);
  const [isPurchased, setIsPurchased] = useState(false);
  const { user } = useAuth();

  const remotePins: RemotePin[] = [
    {
      id: '1',
      name: 'Basic Remote PIN',
      price: 29,
      description: 'Standard remote access PIN for basic trading operations',
      duration: '7 Days'
    },
    {
      id: '2',
      name: 'Premium Remote PIN',
      price: 79,
      description: 'Enhanced remote PIN with advanced security features',
      duration: '30 Days'
    },
    {
      id: '3',
      name: 'Professional Remote PIN',
      price: 149,
      description: 'Professional-grade remote access with priority support',
      duration: '60 Days'
    },
    {
      id: '4',
      name: 'Enterprise Remote PIN',
      price: 299,
      description: 'Enterprise-level remote access with unlimited features',
      duration: '90 Days'
    },
    {
      id: '5',
      name: 'VIP Remote PIN',
      price: 499,
      description: 'VIP remote access with dedicated support and custom features',
      duration: '180 Days'
    },
    {
      id: '6',
      name: 'Lifetime Remote PIN',
      price: 999,
      description: 'One-time purchase for lifetime remote access privileges',
      duration: 'Lifetime'
    }
  ];

  const handlePurchase = async (pinId: string) => {
    const pin = remotePins.find(p => p.id === pinId);
    
    // Send remote pin purchase notification email
    if (user && pin) {
      try {
        const pinEmail = createRemotePinEmail(user.email, user.name, pin.name, pin.price);
        await sendEmailNotification(pinEmail);
      } catch (error) {
        console.error('Failed to send remote pin notification:', error);
      }
    }
    
    setSelectedPin(pinId);
    setIsPurchased(true);
  };

  if (isPurchased && selectedPin) {
    const pin = remotePins.find(p => p.id === selectedPin);
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Remote PIN Purchased!</h2>
          <p className="text-slate-300 mb-6">
            You have successfully purchased <span className="font-bold text-yellow-400">{pin?.name}</span> for ${pin?.price}.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Your remote PIN will be activated within 15 minutes. Check your email for setup instructions.
            </p>
          </div>
          <button
            onClick={() => setIsPurchased(false)}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Browse More PINs
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <Shield className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">Buy Remote PIN</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          Secure remote access PINs for managing your trading account from anywhere. Choose from various duration options with different security levels.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {remotePins.map((pin) => (
          <div key={pin.id} className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-slate-600 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <Shield className="h-8 w-8 text-blue-400" />
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4 text-green-400" />
                <span className="text-sm font-medium text-green-400">{pin.duration}</span>
              </div>
            </div>
            
            <h3 className="text-xl font-bold text-white mb-3">{pin.name}</h3>
            <p className="text-slate-300 mb-6 leading-relaxed">{pin.description}</p>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Duration</span>
                <span className="font-semibold text-green-400">{pin.duration}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Security Level</span>
                <span className="font-semibold text-white">High</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Device Limit</span>
                <span className="font-semibold text-white">
                  {pin.id === '6' ? 'Unlimited' : pin.id === '5' ? '10' : pin.id === '4' ? '5' : pin.id === '3' ? '3' : pin.id === '2' ? '2' : '1'}
                </span>
              </div>
            </div>
            
            <div className="text-center mb-6">
              <div className="text-3xl font-bold text-white mb-1">${pin.price}</div>
              <div className="text-slate-400 text-sm">
                {pin.duration === 'Lifetime' ? 'one-time payment' : `for ${pin.duration.toLowerCase()}`}
              </div>
            </div>
            
            <button
              onClick={() => handlePurchase(pin.id)}
              className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
            >
              Purchase PIN
            </button>
          </div>
        ))}
      </div>

      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <h3 className="text-2xl font-bold text-white mb-6">Remote PIN Features</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Secure remote account access</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Multi-device compatibility</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Real-time trading capabilities</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Advanced encryption</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">24/7 technical support</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Instant activation</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuyRemotePin;