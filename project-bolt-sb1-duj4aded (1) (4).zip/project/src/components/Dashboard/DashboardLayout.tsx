import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  DollarSign, 
  CreditCard, 
  TrendingUp, 
  Shield, 
  Crown, 
  MessageCircle, 
  LogOut,
  Menu,
  X,
  User,
  MessageSquare,
  FileText
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import LiveChat from '../LiveChat';
import DashboardOverview from './DashboardOverview';
import Deposit from './Deposit';
import Withdrawal from './Withdrawal';
import SendMoney from './SendMoney';
import BuySignals from './BuySignals';
import BuyRemotePin from './BuyRemotePin';
import AccountUpgrading from './AccountUpgrading';
import CustomerSupport from './CustomerSupport';
import IDVerification from './IDVerification';

const DashboardLayout = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user, logout } = useAuth();

  const menuItems = [
    { id: 'overview', label: 'Dashboard', icon: <LayoutDashboard className="h-5 w-5" /> },
    { id: 'id-verification', label: 'ID Verification', icon: <FileText className="h-5 w-5" /> },
    { id: 'deposit', label: 'Deposit', icon: <DollarSign className="h-5 w-5" /> },
    { id: 'withdrawal', label: 'Withdrawal', icon: <CreditCard className="h-5 w-5" /> },
    { id: 'signals', label: 'Buy Signals', icon: <TrendingUp className="h-5 w-5" /> },
    { id: 'remote-pin', label: 'Buy Remote PIN', icon: <Shield className="h-5 w-5" /> },
    { id: 'upgrade', label: 'Account Upgrading', icon: <Crown className="h-5 w-5" /> },
    { id: 'support', label: 'Customer Support', icon: <MessageCircle className="h-5 w-5" /> },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <DashboardOverview />;
      case 'id-verification':
        return <IDVerification />;
      case 'deposit':
        return <Deposit />;
      case 'withdrawal':
        return <Withdrawal />;
      case 'send-money':
        return <SendMoney />;
      case 'signals':
        return <BuySignals />;
      case 'remote-pin':
        return <BuyRemotePin />;
      case 'upgrade':
        return <AccountUpgrading />;
      case 'support':
        return <CustomerSupport />;
      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-800 border-r border-slate-700 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-8 w-8 text-yellow-400" />
            <span className="text-xl font-bold text-white">InvestPro</span>
          </div>
          <button
            onClick={() => setIsSidebarOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-slate-900" />
            </div>
            <div>
              <div className="font-medium text-white">{user?.name}</div>
              <div className="text-sm text-slate-400">{user?.email}</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-6">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === item.id
                      ? 'bg-yellow-400 text-slate-900'
                      : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  {item.icon}
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-6 border-t border-slate-700">
          <button
            onClick={logout}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
          >
            <LogOut className="h-5 w-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-slate-800 border-b border-slate-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden text-slate-400 hover:text-white"
            >
              <Menu className="h-6 w-6" />
            </button>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm text-slate-400">Account Balance</div>
                <div className="text-lg font-bold text-white">
                  ${user?.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                user?.accountType === 'vip' ? 'bg-purple-500/20 text-purple-400' :
                user?.accountType === 'premium' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-slate-500/20 text-slate-400'
              }`}>
                {user?.accountType?.toUpperCase()}
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-6">
          {renderContent()}
        </main>

        {/* Live Chat Support */}
        <LiveChat isAuthenticated={true} />

        {/* WhatsApp Support Button */}
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => window.open('https://wa.me/1234567890?text=Hello,%20I%20need%20help%20with%20my%20InvestPro%20account', '_blank')}
            className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 flex items-center gap-3 group"
            title="Contact WhatsApp Support"
          >
            <MessageSquare className="h-6 w-6" />
            <span className="hidden group-hover:block whitespace-nowrap bg-green-600 px-3 py-1 rounded-lg text-sm font-medium absolute right-full mr-3 top-1/2 transform -translate-y-1/2">
              WhatsApp Support
            </span>
          </button>
        </div>
      </div>

      {/* Overlay for mobile */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default DashboardLayout;