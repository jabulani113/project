import React, { useState } from 'react';
import { CreditCard, User, Building, Phone, CheckCircle, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createWithdrawalEmail } from '../../utils/emailService';

const Withdrawal = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    accountNumber: '',
    accountName: '',
    bankName: '',
    accountType: '',
    cellphoneNumber: '',
    amount: '',
    remotePinRequired: false,
    remotePinCode: '',
    remotePinExpiry: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Send withdrawal notification email
    if (user) {
      try {
        const withdrawalEmail = createWithdrawalEmail(user.email, user.name, formData.amount);
        await sendEmailNotification(withdrawalEmail);
      } catch (error) {
        console.error('Failed to send withdrawal notification:', error);
      }
    }
    
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Withdrawal Request Submitted</h2>
          <p className="text-slate-300 mb-6">
            Your withdrawal request for <span className="font-bold text-yellow-400">${formData.amount}</span> has been submitted successfully.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Your request is being processed. You will receive confirmation within 24-48 hours.
            </p>
          </div>
          <button
            onClick={() => setIsSubmitted(false)}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Make Another Withdrawal
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <div className="text-center mb-8">
          <CreditCard className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-2">Withdraw Funds</h2>
          <p className="text-slate-300">Request a withdrawal from your account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Account Number
              </label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  name="accountNumber"
                  value={formData.accountNumber}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter account number"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Account Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  name="accountName"
                  value={formData.accountName}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter account holder name"
                  required
                />
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Bank Name
              </label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  name="bankName"
                  value={formData.bankName}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter bank name"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Account Type
              </label>
              <select
                name="accountType"
                value={formData.accountType}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                required
              >
                <option value="">Select account type</option>
                <option value="checking">Checking Account</option>
                <option value="savings">Savings Account</option>
                <option value="business">Business Account</option>
              </select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Cellphone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="tel"
                  name="cellphoneNumber"
                  value={formData.cellphoneNumber}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter phone number"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Withdrawal Amount
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400">$</span>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  onChange={handleChange}
                  className="w-full pl-8 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  placeholder="Enter amount"
                  min="50"
                  step="0.01"
                  required
                />
              </div>
              <p className="text-slate-400 text-sm mt-2">Minimum withdrawal: $50.00</p>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Remote PIN Information</h3>
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Remote PIN Code
                </label>
                <div className="relative">
                  <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type="text"
                    name="remotePinCode"
                    value={formData.remotePinCode}
                    onChange={handleChange}
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                    placeholder="Enter your Remote PIN"
                    required={formData.remotePinRequired}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  PIN Expiry Date
                </label>
                <input
                  type="date"
                  name="remotePinExpiry"
                  value={formData.remotePinExpiry}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  required={formData.remotePinRequired}
                />
              </div>
            </div>
            
            <h3 className="text-lg font-semibold text-white mb-4">Security Requirements</h3>
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="remotePinRequired"
                name="remotePinRequired"
                checked={formData.remotePinRequired}
                onChange={handleChange}
                className="mt-1 w-4 h-4 text-yellow-400 bg-slate-600 border-slate-500 rounded focus:ring-yellow-400 focus:ring-2"
                required
              />
              <label htmlFor="remotePinRequired" className="text-slate-300 text-sm">
                <span className="font-medium text-white">Remote PIN Required</span>
                <br />
                I confirm that I have purchased a valid Remote PIN and understand that it is required to process this withdrawal request. Without a valid Remote PIN, the withdrawal cannot be completed.
              </label>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Withdrawal Information</h3>
            <div className="space-y-2 text-sm text-slate-300">
              <p>• Processing time: 24-48 hours</p>
              <p>• Minimum withdrawal: $50.00</p>
              <p>• Processing fee: 2% of withdrawal amount</p>
              <p>• Maximum daily withdrawal: $10,000</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={!formData.remotePinRequired}
            className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Submit Withdrawal Request
          </button>
        </form>
      </div>
    </div>
  );
};

export default Withdrawal;