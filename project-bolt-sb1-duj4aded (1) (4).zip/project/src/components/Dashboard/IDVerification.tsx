import React, { useState } from 'react';
import { CreditCard, Upload, CheckCircle, Clock, AlertCircle, FileText, Camera } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification } from '../../utils/emailService';

const IDVerification = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    idNumber: '',
    idType: '',
    frontImage: null as File | null,
    backImage: null as File | null
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [verificationStatus, setVerificationStatus] = useState<'none' | 'submitted' | 'under_review' | 'approved' | 'rejected'>('none');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setError('Please upload only image files (JPG, PNG, etc.)');
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        setError('File size must be less than 5MB');
        return;
      }

      setFormData(prev => ({
        ...prev,
        [side === 'front' ? 'frontImage' : 'backImage']: file
      }));
      setError('');
    }
  };

  const sendVerificationEmail = async () => {
    if (!user) return;

    try {
      const emailData = {
        to: user.email,
        subject: 'ID Verification Submitted - InvestPro',
        message: `
          Dear ${user.name},

          Your ID verification has been submitted successfully.

          Verification Details:
          - ID Type: ${formData.idType}
          - ID Number: ${formData.idNumber}
          - Submission Date: ${new Date().toLocaleString()}
          - Status: Under Review

          Our verification team will review your documents within 24-48 hours. You will receive an email notification once the verification is complete.

          Important Notes:
          - Keep your ID documents safe and accessible
          - Do not share your ID details with unauthorized persons
          - Contact support if you need to update your submission

          Thank you for helping us maintain a secure trading environment.

          Best regards,
          The InvestPro Verification Team
        `,
        timestamp: new Date().toISOString(),
        userInfo: {
          name: user.name,
          email: user.email,
          accountType: user.accountType
        }
      };

      await sendEmailNotification(emailData);
    } catch (error) {
      console.error('Failed to send verification email:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Validate form
    if (!formData.idNumber || !formData.idType || !formData.frontImage || !formData.backImage) {
      setError('Please fill in all fields and upload both ID images');
      setIsLoading(false);
      return;
    }

    try {
      // Simulate API call for ID verification submission
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Send email notification
      await sendVerificationEmail();

      setVerificationStatus('submitted');
      setIsSubmitted(true);
    } catch (err) {
      setError('Failed to submit verification. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Show verification status if already verified or pending
  if (user?.idVerificationStatus === 'approved') {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-green-500 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">ID Verification Approved</h2>
          <p className="text-slate-300 mb-6">
            Your identity has been successfully verified. You now have full access to all platform features.
          </p>
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
            <p className="text-green-400 text-sm">
              ✓ Identity verified • Full account access enabled
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (user?.idVerificationStatus === 'pending' || isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-yellow-500 text-center">
          <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Clock className="h-8 w-8 text-yellow-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Verification Under Review</h2>
          <p className="text-slate-300 mb-6">
            Your ID verification documents have been submitted and are currently under review by our verification team.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              Review typically takes 24-48 hours. You will receive an email notification once completed.
            </p>
          </div>
          <div className="bg-slate-700 rounded-lg p-6 mb-6">
            <h3 className="text-lg font-semibold text-white mb-4">Verification Status</h3>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
              <span className="text-yellow-400 font-medium">Under Review</span>
            </div>
            <div className="mt-4 space-y-2 text-sm text-slate-300">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Documents submitted successfully</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                <span>Manual review in progress</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-slate-500 rounded-full"></div>
                <span>Final approval pending</span>
              </div>
            </div>
          </div>
          <div className="text-left space-y-2 text-sm text-slate-300">
            <p>✓ Documents received and logged</p>
            <p>✓ Initial validation completed</p>
            <p>⏳ Manual review in progress</p>
            <p>⏳ Final approval pending</p>
          </div>
        </div>
      </div>
    );
  }

  if (user?.idVerificationStatus === 'rejected') {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-red-500 text-center">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="h-8 w-8 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Verification Rejected</h2>
          <p className="text-slate-300 mb-6">
            Your ID verification was not approved. Please review the requirements and submit new documents.
          </p>
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
            <p className="text-red-400 text-sm">
              Common issues: Blurry images, expired documents, or incomplete information
            </p>
          </div>
          <button
            onClick={() => window.location.reload()}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Submit New Documents
          </button>
        </div>
      </div>
    );
  }

  // Show status after initial submission
  if (verificationStatus === 'submitted' && !isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
          <div className="text-center mb-8">
            <CreditCard className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-2">ID Verification Status</h2>
            <p className="text-slate-300">Track your verification progress</p>
          </div>

          <div className="bg-slate-700 rounded-lg p-6 mb-6">
            <h3 className="text-xl font-semibold text-white mb-4">Current Status</h3>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-4 h-4 bg-yellow-400 rounded-full animate-pulse"></div>
              <span className="text-yellow-400 font-semibold text-lg">Documents Under Review</span>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-400" />
                <span className="text-slate-300">Documents submitted successfully</span>
                <span className="text-slate-500 text-sm ml-auto">{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-yellow-400 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                </div>
                <span className="text-yellow-400">Manual review in progress</span>
                <span className="text-slate-500 text-sm ml-auto">24-48 hours</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-slate-500" />
                <span className="text-slate-500">Final approval pending</span>
              </div>
            </div>
          </div>

          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              <strong>What happens next?</strong><br />
              Our verification team is reviewing your documents. You'll receive an email notification once the review is complete. This process typically takes 24-48 hours.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="bg-slate-700 rounded-lg p-4">
              <h4 className="font-semibold text-white mb-2">Submitted Documents</h4>
              <div className="space-y-1 text-slate-300">
                <p>• ID Type: {formData.idType || 'Not specified'}</p>
                <p>• ID Number: {formData.idNumber || 'Not specified'}</p>
                <p>• Front Image: ✓ Uploaded</p>
                <p>• Back Image: ✓ Uploaded</p>
              </div>
            </div>
            <div className="bg-slate-700 rounded-lg p-4">
              <h4 className="font-semibold text-white mb-2">Need Help?</h4>
              <div className="space-y-1 text-slate-300">
                <p>• Contact support if urgent</p>
                <p>• Check email for updates</p>
                <p>• Average review: 24-48 hours</p>
                <p>• Status updates via email</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <div className="text-center mb-8">
          <CreditCard className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-white mb-2">ID Verification</h2>
          <p className="text-slate-300">
            Verify your identity to unlock all platform features and ensure account security
          </p>
        </div>

        <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-8">
          <div className="flex items-start gap-3">
            <FileText className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-blue-400 font-medium mb-1">Required Documents</p>
              <p className="text-blue-300 text-sm">
                Please provide a clear photo of both the front and back of your government-issued ID (passport, driver's license, or national ID card).
              </p>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-400" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                ID Type
              </label>
              <select
                name="idType"
                value={formData.idType}
                onChange={handleInputChange}
                className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                required
              >
                <option value="">Select ID type</option>
                <option value="passport">Passport</option>
                <option value="drivers_license">Driver's License</option>
                <option value="national_id">National ID Card</option>
                <option value="state_id">State ID Card</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                ID Number
              </label>
              <input
                type="text"
                name="idNumber"
                value={formData.idNumber}
                onChange={handleInputChange}
                className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                placeholder="Enter your ID number"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Front of ID
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e, 'front')}
                  className="hidden"
                  id="front-upload"
                  required
                />
                <label
                  htmlFor="front-upload"
                  className="w-full h-32 border-2 border-dashed border-slate-600 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-yellow-400 transition-colors bg-slate-700"
                >
                  {formData.frontImage ? (
                    <div className="text-center">
                      <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
                      <p className="text-green-400 text-sm font-medium">Front uploaded</p>
                      <p className="text-slate-400 text-xs">{formData.frontImage.name}</p>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Camera className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-slate-300 text-sm">Upload front of ID</p>
                      <p className="text-slate-400 text-xs">JPG, PNG (max 5MB)</p>
                    </div>
                  )}
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Back of ID
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileChange(e, 'back')}
                  className="hidden"
                  id="back-upload"
                  required
                />
                <label
                  htmlFor="back-upload"
                  className="w-full h-32 border-2 border-dashed border-slate-600 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-yellow-400 transition-colors bg-slate-700"
                >
                  {formData.backImage ? (
                    <div className="text-center">
                      <CheckCircle className="h-8 w-8 text-green-400 mx-auto mb-2" />
                      <p className="text-green-400 text-sm font-medium">Back uploaded</p>
                      <p className="text-slate-400 text-xs">{formData.backImage.name}</p>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Camera className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                      <p className="text-slate-300 text-sm">Upload back of ID</p>
                      <p className="text-slate-400 text-xs">JPG, PNG (max 5MB)</p>
                    </div>
                  )}
                </label>
              </div>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Verification Guidelines</h3>
            <div className="space-y-2 text-sm text-slate-300">
              <p>• Ensure all text on the ID is clearly visible and readable</p>
              <p>• Photos should be well-lit with no shadows or glare</p>
              <p>• ID must be current and not expired</p>
              <p>• All four corners of the ID should be visible in the photo</p>
              <p>• File size should not exceed 5MB per image</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
                Submitting Verification...
              </>
            ) : (
              <>
                <Upload className="h-5 w-5" />
                Submit for Verification
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-slate-400 text-sm">
            Your documents are encrypted and stored securely. We never share your personal information with third parties.
          </p>
        </div>
      </div>
    </div>
  );
};

export default IDVerification;