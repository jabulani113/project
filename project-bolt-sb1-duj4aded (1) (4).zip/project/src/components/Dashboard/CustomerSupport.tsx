import React, { useState } from 'react';
import { MessageCircle, Phone, Mail, Clock, Send, User, MessageSquare } from 'lucide-react';

const CustomerSupport = () => {
  const [activeTab, setActiveTab] = useState('chat');
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState([
    {
      id: 1,
      sender: 'support',
      message: 'Hello! How can I help you today?',
      time: '10:30 AM'
    }
  ]);

  const sendSupportEmail = async () => {
    try {
      const emailData = {
        to: 'support@investpro.com', // Replace with your actual support email
        subject: `Email Support Request - Dashboard User`,
        message: `
          Subject: ${(document.querySelector('select[name="subject"]') as HTMLSelectElement)?.value || 'General Inquiry'}
          Priority: ${(document.querySelector('select[name="priority"]') as HTMLSelectElement)?.value || 'Normal'}
          
          Message:
          ${(document.querySelector('textarea') as HTMLTextAreaElement)?.value || ''}
          
          User: Dashboard User
          Timestamp: ${new Date().toLocaleString()}
        `,
        timestamp: new Date().toISOString(),
        source: 'Email Support Form'
      };

      // Log the support request
      console.log('Email support request:', emailData);
      
      // For production, send to your backend API
      // await fetch('/api/support/email', { method: 'POST', body: JSON.stringify(emailData) });
      
    } catch (error) {
      console.error('Error sending email support request:', error);
    }
  };

  const handleChatMessage = async (message: string) => {
    try {
      const emailData = {
        to: 'support@investpro.com', // Replace with your actual support email
        subject: 'Live Chat Message - Dashboard User',
        message: message,
        timestamp: new Date().toISOString(),
        source: 'Dashboard Live Chat'
      };
      
      // Log the support request
      console.log('Chat support request:', emailData);
      
      // For production, send to your backend API
      // await fetch('/api/support/chat', { method: 'POST', body: JSON.stringify(emailData) });
      
    } catch (error) {
      console.error('Error sending chat support request:', error);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newMessage = {
      id: chatMessages.length + 1,
      sender: 'user',
      message: message,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages([...chatMessages, newMessage]);
    
    // Send message to email
    handleChatMessage(message);
    
    setMessage('');

    // Simulate support response
    setTimeout(() => {
      const supportResponse = {
        id: chatMessages.length + 2,
        sender: 'support',
        message: 'Thank you for your message. Our support team has received your inquiry and will respond via email shortly.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, supportResponse]);
    }, 1000);
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <MessageCircle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">Customer Support</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          Get help from our expert support team. We're here to assist you with any questions or issues you may have.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-slate-800 rounded-2xl border border-slate-700">
            <div className="flex border-b border-slate-700">
              <button
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-4 px-6 font-medium transition-colors ${
                  activeTab === 'chat'
                    ? 'text-yellow-400 border-b-2 border-yellow-400'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                Live Chat
              </button>
              <button
                onClick={() => setActiveTab('email')}
                className={`flex-1 py-4 px-6 font-medium transition-colors ${
                  activeTab === 'email'
                    ? 'text-yellow-400 border-b-2 border-yellow-400'
                    : 'text-slate-400 hover:text-slate-300'
                }`}
              >
                Email Support
              </button>
            </div>

            {activeTab === 'chat' && (
              <div className="p-6">
                <div className="h-96 bg-slate-700 rounded-lg p-4 mb-4 overflow-y-auto">
                  {chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`mb-4 flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          msg.sender === 'user'
                            ? 'bg-yellow-400 text-slate-900'
                            : 'bg-slate-600 text-white'
                        }`}
                      >
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${
                          msg.sender === 'user' ? 'text-slate-700' : 'text-slate-400'
                        }`}>
                          {msg.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors"
                  />
                  <button
                    type="submit"
                    className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors flex items-center gap-2"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'email' && (
              <div className="p-6">
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Subject
                      </label>
                      <select name="subject" className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors">
                        <option>Account Issues</option>
                        <option>Deposit/Withdrawal</option>
                        <option>Trading Questions</option>
                        <option>Technical Support</option>
                        <option>General Inquiry</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        Priority
                      </label>
                      <select name="priority" className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors">
                        <option>Normal</option>
                        <option>High</option>
                        <option>Urgent</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Message
                    </label>
                    <textarea
                      rows={6}
                      className="w-full px-4 py-3 rounded-lg border border-slate-600 bg-slate-700 text-white focus:ring-2 focus:ring-yellow-400 focus:border-yellow-400 transition-colors resize-none"
                      placeholder="Describe your issue or question in detail..."
                    />
                  </div>

                  <button
                    type="submit"
                    onClick={sendSupportEmail}
                    className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
                  >
                    Send Email
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-yellow-400" />
                <div>
                  <div className="font-medium text-white">Phone Support</div>
                  <div className="text-slate-300 text-sm">+1-800-TRADE-24</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-yellow-400" />
                <div>
                  <div className="font-medium text-white">Email Support</div>
                  <div className="text-slate-300 text-sm">support@investpro.com</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-yellow-400" />
                <div>
                  <div className="font-medium text-white">Support Hours</div>
                  <div className="text-slate-300 text-sm">24/7 Available</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">Quick Help</h3>
            <div className="space-y-3">
              <button 
                onClick={() => window.open('https://wa.me/1234567890?text=Hello,%20I%20need%20help%20with%20deposits%20and%20withdrawals', '_blank')}
                className="w-full text-left p-3 rounded-lg bg-green-600 hover:bg-green-700 transition-colors"
              >
                <div className="font-medium text-white flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  WhatsApp Quick Support
                </div>
                <div className="text-green-100 text-sm">Get instant help via WhatsApp</div>
              </button>
              <button className="w-full text-left p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <div className="font-medium text-white">How to deposit funds?</div>
                <div className="text-slate-400 text-sm">Step-by-step deposit guide</div>
              </button>
              <button className="w-full text-left p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <div className="font-medium text-white">Withdrawal process</div>
                <div className="text-slate-400 text-sm">Learn about withdrawals</div>
              </button>
              <button className="w-full text-left p-3 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors">
                <div className="font-medium text-white">Account verification</div>
                <div className="text-slate-400 text-sm">Verify your account</div>
              </button>
            </div>
          </div>

          <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
            <h3 className="text-xl font-bold text-white mb-4">Response Times</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-300">Live Chat</span>
                <span className="text-green-400">Instant</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">WhatsApp</span>
                <span className="text-green-400">Instant</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Email Support</span>
                <span className="text-yellow-400">2-4 hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-300">Phone Support</span>
                <span className="text-green-400">Immediate</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerSupport;