import React, { useState } from 'react';
import { TrendingUp, Star, Clock, CheckCircle } from 'lucide-react';
import { Signal } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { sendEmailNotification, createSignalPurchaseEmail } from '../../utils/emailService';

const BuySignals = () => {
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);
  const [isPurchased, setIsPurchased] = useState(false);
  const { user } = useAuth();

  const signals: Signal[] = [
    {
      id: '1',
      name: 'Premium Forex Signals',
      price: 99,
      description: 'High-accuracy forex trading signals with 85% success rate',
      accuracy: '85%'
    },
    {
      id: '2',
      name: 'Crypto Master Signals',
      price: 149,
      description: 'Cryptocurrency trading signals for major coins and altcoins',
      accuracy: '78%'
    },
    {
      id: '3',
      name: 'Stock Market Pro',
      price: 199,
      description: 'Professional stock market signals for day and swing trading',
      accuracy: '82%'
    },
    {
      id: '4',
      name: 'Binary Options Elite',
      price: 79,
      description: 'Binary options signals with precise entry and exit points',
      accuracy: '76%'
    },
    {
      id: '5',
      name: 'Commodities Expert',
      price: 129,
      description: 'Gold, oil, and commodity trading signals from market experts',
      accuracy: '80%'
    },
    {
      id: '6',
      name: 'VIP All-Access',
      price: 299,
      description: 'Complete access to all signal types with priority support',
      accuracy: '88%'
    }
  ];

  const handlePurchase = async (signalId: string) => {
    const signal = signals.find(s => s.id === signalId);
    
    // Send signal purchase notification email
    if (user && signal) {
      try {
        const signalEmail = createSignalPurchaseEmail(user.email, user.name, signal.name, signal.price);
        await sendEmailNotification(signalEmail);
      } catch (error) {
        console.error('Failed to send signal purchase notification:', error);
      }
    }
    
    setSelectedSignal(signalId);
    setIsPurchased(true);
  };

  if (isPurchased && selectedSignal) {
    const signal = signals.find(s => s.id === selectedSignal);
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Signal Package Purchased!</h2>
          <p className="text-slate-300 mb-6">
            You have successfully purchased <span className="font-bold text-yellow-400">{signal?.name}</span> for ${signal?.price}.
          </p>
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-6">
            <p className="text-blue-400 text-sm">
              You will receive your first signals within the next hour. Check your email for access instructions.
            </p>
          </div>
          <button
            onClick={() => setIsPurchased(false)}
            className="bg-yellow-400 text-slate-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
          >
            Browse More Signals
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <TrendingUp className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-white mb-4">Buy Trading Signals</h2>
        <p className="text-slate-300 max-w-2xl mx-auto">
          Get access to professional trading signals from our expert analysts. Choose from various signal packages tailored to different markets and trading styles.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {signals.map((signal) => (
          <div key={signal.id} className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-slate-600 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="h-8 w-8 text-yellow-400" />
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="text-sm font-medium text-yellow-400">{signal.accuracy}</span>
              </div>
            </div>
            
            <h3 className="text-xl font-bold text-white mb-3">{signal.name}</h3>
            <p className="text-slate-300 mb-6 leading-relaxed">{signal.description}</p>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Accuracy Rate</span>
                <span className="font-semibold text-green-400">{signal.accuracy}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Duration</span>
                <span className="font-semibold text-white">30 Days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Signals per Day</span>
                <span className="font-semibold text-white">3-5</span>
              </div>
            </div>
            
            <div className="text-center mb-6">
              <div className="text-3xl font-bold text-white mb-1">${signal.price}</div>
              <div className="text-slate-400 text-sm">per month</div>
            </div>
            
            <button
              onClick={() => handlePurchase(signal.id)}
              className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
            >
              Purchase Now
            </button>
          </div>
        ))}
      </div>

      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <h3 className="text-2xl font-bold text-white mb-6">What's Included</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Real-time signal notifications</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Entry and exit points</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Stop loss recommendations</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Market analysis reports</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">24/7 customer support</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-400" />
              <span className="text-slate-300">Mobile app access</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BuySignals;