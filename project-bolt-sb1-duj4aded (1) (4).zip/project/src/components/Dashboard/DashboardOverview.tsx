import React from 'react';
import { Wallet, TrendingUp, Gift, Clock, Bell, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const DashboardOverview = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = React.useState([
    {
      id: 1,
      type: 'info',
      title: 'Welcome to InvestPro',
      message: 'Your account has been successfully verified. You can now access all trading features.',
      timestamp: new Date().toISOString(),
      read: false
    },
    {
      id: 2,
      type: 'warning',
      title: 'Security Notice',
      message: 'Please ensure you only send money to our official company database account. Never send funds to individual agents or personal accounts.',
      timestamp: new Date().toISOString(),
      read: false
    },
    {
      id: 3,
      type: 'success',
      title: 'Account Upgrade Available',
      message: 'Upgrade your account to Premium or VIP to unlock advanced trading features and reduced fees.',
      timestamp: new Date().toISOString(),
      read: false
    }
  ]);

  const dismissNotification = (id: number) => {
    setNotifications(notifications.filter(notification => notification.id !== id));
  };

  if (!user) return null;

  const stats = [
    {
      icon: <Wallet className="h-8 w-8 text-blue-400" />,
      title: "Available Balance",
      value: `$${user.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      color: "from-blue-500 to-blue-700"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-purple-400" />,
      title: "Total Deposit",
      value: `$${user.totalDeposit.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      color: "from-purple-500 to-purple-700"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-green-400" />,
      title: "Total Profit",
      value: `$${user.totalProfit.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      color: "from-green-500 to-green-700"
    },
    {
      icon: <Gift className="h-8 w-8 text-yellow-400" />,
      title: "Bonus",
      value: `$${user.bonus.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      color: "from-yellow-500 to-yellow-700"
    },
    {
      icon: <Clock className="h-8 w-8 text-purple-400" />,
      title: "Withdrawal Status",
      value: user.withdrawalStatus === 'none' ? 'No Pending' : user.withdrawalStatus.charAt(0).toUpperCase() + user.withdrawalStatus.slice(1),
      color: "from-indigo-500 to-indigo-700"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Notifications Section */}
      {notifications.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-yellow-400" />
            <h2 className="text-xl font-semibold text-white">Notifications</h2>
            <span className="bg-yellow-400 text-slate-900 text-xs font-bold px-2 py-1 rounded-full">
              {notifications.filter(n => !n.read).length}
            </span>
          </div>
          
          <div className="space-y-3">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`bg-slate-800 rounded-lg p-4 border-l-4 ${
                  notification.type === 'success' ? 'border-green-400' :
                  notification.type === 'warning' ? 'border-yellow-400' :
                  notification.type === 'error' ? 'border-red-400' :
                  'border-blue-400'
                } border border-slate-700 relative`}
              >
                <button
                  onClick={() => dismissNotification(notification.id)}
                  className="absolute top-2 right-2 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
                
                <div className="pr-8">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-white">{notification.title}</h3>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      notification.type === 'success' ? 'bg-green-500/20 text-green-400' :
                      notification.type === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                      notification.type === 'error' ? 'bg-red-500/20 text-red-400' :
                      'bg-blue-500/20 text-blue-400'
                    }`}>
                      {notification.type.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {notification.message}
                  </p>
                  <p className="text-slate-500 text-xs mt-2">
                    {new Date(notification.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">
          Welcome back, {user.name}!
        </h1>
        <p className="text-slate-300">
          Here's your trading overview for today
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-slate-600 transition-colors">
            <div className={`h-2 bg-gradient-to-r ${stat.color} rounded-full mb-4`}></div>
            <div className="flex items-center justify-between mb-4">
              {stat.icon}
              <div className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${stat.color} text-white`}>
                Active
              </div>
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">{stat.title}</h3>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
        <h3 className="text-2xl font-bold text-white mb-6">Account Summary</h3>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-2">
              +{((user.totalProfit / (user.balance - user.totalProfit)) * 100).toFixed(1)}%
            </div>
            <div className="text-slate-300">Total Return</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-400 mb-2">
              {user.accountType.charAt(0).toUpperCase() + user.accountType.slice(1)}
            </div>
            <div className="text-slate-300">Account Type</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-400 mb-2">
              ${(user.balance + user.totalDeposit + user.totalProfit + user.bonus).toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-slate-300">Total Value</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;