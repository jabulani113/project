import React, { useState } from 'react';
import { Menu, X, TrendingUp } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './Auth/AuthModal';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const { isAuthenticated, user } = useAuth();

  const handleAuthClick = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  return (
    <>
      <header className="bg-slate-900 shadow-lg fixed w-full top-0 z-50 border-b border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-8 w-8 text-yellow-400" />
            <span className="text-2xl font-bold text-white">NITROTRADING</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Home</a>
            <a href="#investments" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Investments</a>
            <a href="#performance" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Performance</a>
            <a href="#about" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">About</a>
            <a href="#contact" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Contact</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <span className="text-slate-300">Welcome, {user?.name}</span>
                <button 
                  onClick={() => window.location.href = '#dashboard'}
                  className="bg-yellow-400 text-slate-900 px-6 py-2 rounded-lg hover:bg-yellow-300 transition-colors font-medium"
                >
                  Dashboard
                </button>
              </div>
            ) : (
              <>
                <button 
                  onClick={() => handleAuthClick('login')}
                  className="text-yellow-400 hover:text-yellow-300 font-medium"
                >
                  Login
                </button>
                <button 
                  onClick={() => handleAuthClick('register')}
                  className="bg-yellow-400 text-slate-900 px-6 py-2 rounded-lg hover:bg-yellow-300 transition-colors font-medium"
                >
                  Get Started
                </button>
              </>
            )}
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-700">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Home</a>
              <a href="#investments" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Investments</a>
              <a href="#performance" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Performance</a>
              <a href="#about" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">About</a>
              <a href="#contact" className="text-slate-300 hover:text-yellow-400 transition-colors font-medium">Contact</a>
              {!isAuthenticated && (
                <div className="flex flex-col space-y-2 pt-4 border-t border-slate-700">
                  <button 
                    onClick={() => handleAuthClick('login')}
                    className="text-yellow-400 hover:text-yellow-300 font-medium text-left"
                  >
                    Login
                  </button>
                  <button 
                    onClick={() => handleAuthClick('register')}
                    className="bg-yellow-400 text-slate-900 px-6 py-2 rounded-lg hover:bg-yellow-300 transition-colors font-medium"
                  >
                    Get Started
                  </button>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
      </header>
      
      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authMode}
      />
    </>
  );
};

export default Header;