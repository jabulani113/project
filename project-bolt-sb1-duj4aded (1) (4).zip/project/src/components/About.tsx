import React from 'react';
import { Award, Shield, Users, Target } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: <Shield className="h-12 w-12 text-blue-600" />,
      title: "Security First",
      description: "Bank-level security with insurance coverage up to $500,000 per account."
    },
    {
      icon: <Users className="h-12 w-12 text-green-600" />,
      title: "Client-Centric",
      description: "Every decision we make is guided by what's best for our investors."
    },
    {
      icon: <Target className="h-12 w-12 text-purple-600" />,
      title: "Goal-Oriented",
      description: "We align our strategies with your specific financial objectives."
    },
    {
      icon: <Award className="h-12 w-12 text-yellow-600" />,
      title: "Award-Winning",
      description: "Recognized by industry leaders for innovation and performance."
    }
  ];

  const team = [
    {
      name: "Sarah Johnson",
      role: "Chief Investment Officer",
      image: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=400",
      experience: "15+ years"
    },
    {
      name: "Michael Chen",
      role: "Senior Portfolio Manager",
      image: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400",
      experience: "12+ years"
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Research",
      image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400",
      experience: "10+ years"
    }
  ];

  return (
    <section id="about" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Why Choose InvestPro
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Founded in 2010, we've helped thousands of investors achieve their financial goals through disciplined strategies and unwavering commitment to excellence.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {values.map((value, index) => (
            <div key={index} className="text-center group">
              <div className="inline-flex items-center justify-center mb-6 transform group-hover:scale-110 transition-transform">
                {value.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{value.title}</h3>
              <p className="text-slate-300 leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-slate-800 rounded-3xl shadow-lg p-12 border border-slate-700">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-white mb-4">
              Meet Our Expert Team
            </h3>
            <p className="text-xl text-slate-300">
              Led by industry veterans with decades of combined experience in wealth management and investment strategy.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <img 
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 w-32 h-32 rounded-full mx-auto bg-gradient-to-t from-slate-900/20 to-transparent"></div>
                </div>
                <h4 className="text-xl font-bold text-white mb-2">{member.name}</h4>
                <p className="text-yellow-400 font-medium mb-2">{member.role}</p>
                <p className="text-slate-400 text-sm">{member.experience} Experience</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;