import React, { useState } from 'react';
import { Play, Star, Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const VideoTestimonials = () => {
  const [activeVideo, setActiveVideo] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      location: "New York, USA",
      profession: "Financial Analyst",
      videoThumbnail: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "NitroTrading transformed my investment strategy. I've seen consistent 18% returns over the past year.",
      results: "$45,000 profit in 12 months",
      duration: "2:34"
    },
    {
      id: 2,
      name: "Michael Chen",
      location: "London, UK",
      profession: "Software Engineer",
      videoThumbnail: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "The signals are incredibly accurate. I went from losing money to making consistent profits.",
      results: "$28,500 profit in 8 months",
      duration: "3:12"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      location: "Toronto, Canada",
      profession: "Marketing Director",
      videoThumbnail: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "NitroTrading's platform is user-friendly and their support team is exceptional. Highly recommended!",
      results: "$62,000 profit in 14 months",
      duration: "2:58"
    },
    {
      id: 4,
      name: "David Thompson",
      location: "Sydney, Australia",
      profession: "Business Owner",
      videoThumbnail: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "I started with $5,000 and now my portfolio is worth over $50,000. NitroTrading made it possible.",
      results: "$45,000 portfolio growth",
      duration: "4:21"
    },
    {
      id: 5,
      name: "Lisa Wang",
      location: "Singapore",
      profession: "Investment Banker",
      videoThumbnail: "https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "The educational resources and trading signals helped me become a better trader. Amazing platform!",
      results: "$73,200 profit in 18 months",
      duration: "3:45"
    },
    {
      id: 6,
      name: "James Miller",
      location: "Chicago, USA",
      profession: "Retired Teacher",
      videoThumbnail: "https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=400",
      videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Demo video
      rating: 5,
      quote: "At 65, I thought it was too late to start trading. NitroTrading proved me wrong!",
      results: "$31,800 retirement boost",
      duration: "2:47"
    }
  ];

  const nextVideo = () => {
    setActiveVideo((prev) => (prev + 1) % testimonials.length);
  };

  const prevVideo = () => {
    setActiveVideo((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const currentTestimonial = testimonials[activeVideo];

  return (
    <section className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Real Success Stories from NitroTrading Users
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Hear directly from our successful traders about their journey and results with NitroTrading platform.
          </p>
        </div>

        {/* Main Video Player */}
        <div className="mb-12">
          <div className="bg-slate-800 rounded-3xl p-8 border border-slate-700">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              {/* Video Player */}
              <div className="relative">
                <div className="aspect-video bg-slate-700 rounded-2xl overflow-hidden relative group">
                  <img 
                    src={currentTestimonial.videoThumbnail}
                    alt={currentTestimonial.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center group-hover:bg-opacity-30 transition-all">
                    <button className="w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center hover:bg-yellow-300 transition-colors transform hover:scale-110">
                      <Play className="h-8 w-8 text-slate-900 ml-1" />
                    </button>
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black bg-opacity-75 text-white px-3 py-1 rounded-lg text-sm">
                    {currentTestimonial.duration}
                  </div>
                </div>
              </div>

              {/* Testimonial Content */}
              <div>
                <div className="flex items-center mb-4">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <div className="relative mb-6">
                  <Quote className="h-8 w-8 text-yellow-400 mb-4" />
                  <blockquote className="text-xl text-white leading-relaxed mb-4">
                    "{currentTestimonial.quote}"
                  </blockquote>
                </div>

                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-6">
                  <div className="text-green-400 font-semibold text-lg">
                    {currentTestimonial.results}
                  </div>
                  <div className="text-green-300 text-sm">Verified Trading Results</div>
                </div>

                <div className="flex items-center space-x-4">
                  <img 
                    src={currentTestimonial.videoThumbnail}
                    alt={currentTestimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-white">{currentTestimonial.name}</div>
                    <div className="text-slate-400 text-sm">{currentTestimonial.profession}</div>
                    <div className="text-slate-500 text-sm">{currentTestimonial.location}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center justify-between mt-8">
              <button
                onClick={prevVideo}
                className="flex items-center space-x-2 text-slate-400 hover:text-yellow-400 transition-colors"
              >
                <ChevronLeft className="h-5 w-5" />
                <span>Previous</span>
              </button>
              
              <div className="text-slate-400 text-sm">
                {activeVideo + 1} of {testimonials.length}
              </div>
              
              <button
                onClick={nextVideo}
                className="flex items-center space-x-2 text-slate-400 hover:text-yellow-400 transition-colors"
              >
                <span>Next</span>
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Testimonial Thumbnails */}
        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
          {testimonials.map((testimonial, index) => (
            <button
              key={testimonial.id}
              onClick={() => setActiveVideo(index)}
              className={`relative group ${
                index === activeVideo ? 'ring-2 ring-yellow-400' : ''
              }`}
            >
              <div className="aspect-video bg-slate-700 rounded-lg overflow-hidden">
                <img 
                  src={testimonial.videoThumbnail}
                  alt={testimonial.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center group-hover:bg-opacity-30 transition-all">
                  <Play className="h-6 w-6 text-white" />
                </div>
                <div className="absolute bottom-1 right-1 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs">
                  {testimonial.duration}
                </div>
              </div>
              <div className="mt-2 text-center">
                <div className="text-white text-sm font-medium">{testimonial.name}</div>
                <div className="text-slate-400 text-xs">{testimonial.location}</div>
              </div>
            </button>
          ))}
        </div>

        {/* Success Stats */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-3xl p-8 border border-slate-600">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-white mb-4">
              Proven Results from Our Community
            </h3>
            <p className="text-slate-300">
              Join thousands of successful traders who have transformed their financial future with NitroTrading.
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">$2.4M+</div>
              <div className="text-slate-300">Total Profits Generated</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-green-400 mb-2">87%</div>
              <div className="text-slate-300">Success Rate</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-400 mb-2">15,000+</div>
              <div className="text-slate-300">Active Traders</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-400 mb-2">4.9/5</div>
              <div className="text-slate-300">Average Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VideoTestimonials;