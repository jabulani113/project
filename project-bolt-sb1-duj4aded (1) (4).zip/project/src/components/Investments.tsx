import React from 'react';
import { TrendingUp, Shield, Zap, Globe, Building, Leaf } from 'lucide-react';

const Investments = () => {
  const portfolios = [
    {
      icon: <TrendingUp className="h-8 w-8 text-blue-600" />,
      title: "Growth Portfolio",
      description: "High-potential stocks and emerging markets for aggressive growth",
      return: "18.2%",
      risk: "High",
      minInvestment: "$1,000",
      color: "from-blue-500 to-blue-700"
    },
    {
      icon: <Shield className="h-8 w-8 text-green-600" />,
      title: "Conservative Portfolio",
      description: "Stable bonds and dividend-paying stocks for steady income",
      return: "8.4%",
      risk: "Low",
      minInvestment: "$500",
      color: "from-green-500 to-green-700"
    },
    {
      icon: <Zap className="h-8 w-8 text-yellow-600" />,
      title: "Tech Innovation",
      description: "Cutting-edge technology companies and disruptive innovations",
      return: "22.7%",
      risk: "High",
      minInvestment: "$2,500",
      color: "from-yellow-500 to-yellow-700"
    },
    {
      icon: <Globe className="h-8 w-8 text-purple-600" />,
      title: "Global Diversified",
      description: "International markets and currencies for global exposure",
      return: "14.1%",
      risk: "Medium",
      minInvestment: "$750",
      color: "from-purple-500 to-purple-700"
    },
    {
      icon: <Building className="h-8 w-8 text-indigo-600" />,
      title: "Real Estate Fund",
      description: "REITs and property investments for stable cash flow",
      return: "11.6%",
      risk: "Medium",
      minInvestment: "$1,500",
      color: "from-indigo-500 to-indigo-700"
    },
    {
      icon: <Leaf className="h-8 w-8 text-emerald-600" />,
      title: "ESG Sustainable",
      description: "Environmental, social, and governance focused investments",
      return: "13.8%",
      risk: "Medium",
      minInvestment: "$1,000",
      color: "from-emerald-500 to-emerald-700"
    }
  ];

  return (
    <section id="investments" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Investment Portfolios
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Choose from our expertly crafted portfolios, each designed to meet different risk tolerances and investment goals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolios.map((portfolio, index) => (
            <div 
              key={index} 
              className="bg-slate-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden border border-slate-700"
            >
              <div className={`h-2 bg-gradient-to-r ${portfolio.color}`}></div>
              <div className="p-8">
                <div className="flex items-center justify-between mb-4">
                  {portfolio.icon}
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    portfolio.risk === 'High' ? 'bg-red-100 text-red-800' :
                    portfolio.risk === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {portfolio.risk} Risk
                  </span>
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-3">
                  {portfolio.title}
                </h3>
                
                <p className="text-slate-300 mb-6 leading-relaxed">
                  {portfolio.description}
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Annual Return</span>
                    <span className="font-bold text-green-600 text-lg">{portfolio.return}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Min. Investment</span>
                    <span className="font-semibold text-white">{portfolio.minInvestment}</span>
                  </div>
                </div>
                
                <button className={`w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r ${portfolio.color} hover:opacity-90 transition-opacity`}>
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Investments;