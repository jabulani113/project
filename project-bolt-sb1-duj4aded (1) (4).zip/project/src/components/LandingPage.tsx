import React, { useState } from 'react';
import { AlertTriangle, X, MessageSquare } from 'lucide-react';
import Header from './Header';
import Hero from './Hero';
import ForexSignals from './ForexSignals';
import VideoTestimonials from './VideoTestimonials';
import Investments from './Investments';
import Performance from './Performance';
import About from './About';
import Contact from './Contact';
import Footer from './Footer';
import AuthModal from './Auth/AuthModal';
import LiveChat from './LiveChat';

interface LandingPageProps {
  interfaceType?: 'public' | 'dashboard';
}

const LandingPage: React.FC<LandingPageProps> = ({ interfaceType = 'public' }) => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showSecurityWarning, setShowSecurityWarning] = useState(true);

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  // Public Interface - Marketing/Landing Page
  if (interfaceType === 'public') {
    return (
      <>
        {/* Security Warning Modal */}
        {showSecurityWarning && (
          <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-slate-800 rounded-2xl p-8 border border-red-500 max-w-md w-full relative">
              <button
                onClick={() => setShowSecurityWarning(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <AlertTriangle className="h-8 w-8 text-red-400" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-4">
                  Important Security Notice
                </h2>
                
                <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 mb-6">
                  <p className="text-red-400 font-medium mb-2">⚠️ FRAUD PREVENTION ALERT</p>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Please <strong className="text-white">DO NOT send money</strong> to any account, agent, or individual 
                    apart from our company's official database account. Only use verified payment methods 
                    provided through our secure platform.
                  </p>
                </div>
                
                <div className="space-y-2 text-sm text-slate-300 mb-6">
                  <p>✓ All legitimate transactions go through our secure system</p>
                  <p>✓ We will never ask for payments via personal accounts</p>
                  <p>✓ Always verify payment instructions through our platform</p>
                </div>
                
                <button
                  onClick={() => setShowSecurityWarning(false)}
                  className="w-full bg-yellow-400 text-slate-900 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
                >
                  I Understand - Continue to Website
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="min-h-screen">
          <Header />
          <Hero onOpenAuth={handleOpenAuth} />
          <ForexSignals />
          <VideoTestimonials />
          <Investments />
          <Performance onOpenAuth={handleOpenAuth} />
          <About />
          <Contact />
          <Footer />
        </div>
        
        <AuthModal 
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          initialMode={authMode}
        />
        
        {/* Live Chat Support */}
        <LiveChat isAuthenticated={false} />
        
        {/* WhatsApp Support Button */}
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => window.open('https://wa.me/1234567890?text=Hello,%20I%20need%20help%20with%20InvestPro%20services', '_blank')}
            className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 flex items-center gap-3 group"
            title="Contact WhatsApp Support"
          >
            <MessageSquare className="h-6 w-6" />
            <span className="hidden group-hover:block whitespace-nowrap bg-green-600 px-3 py-1 rounded-lg text-sm font-medium absolute right-full mr-3 top-1/2 transform -translate-y-1/2">
              WhatsApp Support
            </span>
          </button>
        </div>
      </>
    );
  }

  // Dashboard Interface - Simplified for authenticated users
  return (
    <div className="min-h-screen bg-slate-900">
      {/* Simplified Dashboard Header */}
      <div className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-yellow-400 rounded-full"></div>
            <span className="text-xl font-bold text-white">InvestPro Dashboard</span>
          </div>
          <div className="text-slate-300 text-sm">
            Authenticated User Interface
          </div>
        </div>
      </div>
      
      {/* Dashboard Content */}
      <div className="p-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-white mb-6">
            Welcome to Your Dashboard
          </h1>
          <p className="text-xl text-slate-300 mb-8">
            This is the authenticated user interface with full trading capabilities.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-3">Trading Tools</h3>
              <p className="text-slate-300 text-sm">
                Access advanced trading features and real-time market data.
              </p>
            </div>
            <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-3">Portfolio Management</h3>
              <p className="text-slate-300 text-sm">
                Manage your investments and track performance.
              </p>
            </div>
            <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-3">Account Services</h3>
              <p className="text-slate-300 text-sm">
                Deposits, withdrawals, and account management.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;