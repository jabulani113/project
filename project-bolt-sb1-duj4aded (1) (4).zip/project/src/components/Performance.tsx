import React from 'react';
import { BarChart3, TrendingUp, DollarSign, Users } from 'lucide-react';

interface PerformanceProps {
  onOpenAuth?: (mode: 'login' | 'register') => void;
}

const Performance: React.FC<PerformanceProps> = ({ onOpenAuth }) => {
  const stats = [
    {
      icon: <DollarSign className="h-8 w-8 text-yellow-600" />,
      value: "$2.4B",
      label: "Assets Under Management",
      change: "+15.2% this year"
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-green-600" />,
      value: "14.8%",
      label: "Average Annual Return",
      change: "Above market average"
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      value: "52,341",
      label: "Active Investors",
      change: "+2,847 this month"
    },
    {
      icon: <BarChart3 className="h-8 w-8 text-purple-600" />,
      value: "98.7%",
      label: "Client Satisfaction",
      change: "Based on 2024 survey"
    }
  ];

  return (
    <section id="performance" className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Performance That Speaks
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Our track record demonstrates consistent growth and superior returns across all market conditions.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-800 group-hover:bg-slate-700 transition-colors mb-4">
                {stat.icon}
              </div>
              <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
              <div className="text-lg font-medium text-slate-300 mb-1">{stat.label}</div>
              <div className="text-sm text-slate-400">{stat.change}</div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-3xl p-12 text-white border border-slate-600">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6">
                Ready to Start Your Investment Journey?
              </h3>
              <p className="text-xl text-slate-200 mb-8">
                Join thousands of satisfied investors who have already secured their financial future with our proven strategies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => onOpenAuth?.('register')}
                  className="bg-yellow-400 text-slate-900 px-8 py-4 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
                >
                  Open Free Account
                </button>
                <button 
                  onClick={() => onOpenAuth?.('login')}
                  className="border-2 border-slate-300 text-slate-100 px-8 py-4 rounded-lg font-semibold hover:bg-slate-600 transition-colors"
                >
                  Schedule Consultation
                </button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/6120214/pexels-photo-6120214.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Investment Success"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Performance;