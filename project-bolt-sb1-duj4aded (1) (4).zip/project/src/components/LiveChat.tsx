import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Minimize2, Maximize2, User, Headphones } from 'lucide-react';

interface Message {
  id: number;
  sender: 'user' | 'support';
  message: string;
  time: string;
}

interface LiveChatProps {
  isAuthenticated?: boolean;
}

const LiveChat: React.FC<LiveChatProps> = ({ isAuthenticated = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: 'support',
      message: 'Hello! Welcome to InvestPro. How can I help you today?',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newMessage: Message = {
      id: messages.length + 1,
      sender: 'user',
      message: message.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMessage]);
    
    // Send message to email
    sendMessageToEmail(message.trim(), isAuthenticated);
    
    setMessage('');
    setIsTyping(true);

    // Simulate support response
    setTimeout(() => {
      const responses = [
        "Thank you for your message. Our support team has received your inquiry and will respond via email shortly.",
        "Your message has been forwarded to our customer support team. You'll receive a detailed response in your email within 2-4 hours.",
        "We've received your inquiry and our specialists are reviewing it. Expect a comprehensive response via email soon.",
        "Your support request has been logged. Our team will contact you via email with a detailed solution.",
        "Thank you for reaching out. Our support team will send you a personalized response via email within a few hours."
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      const supportResponse: Message = {
        id: messages.length + 2,
        sender: 'support',
        message: randomResponse,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, supportResponse]);
      setIsTyping(false);
    }, 2000);
  };

  const sendMessageToEmail = async (userMessage: string, authenticated: boolean) => {
    try {
      const emailData = {
        to: 'support@investpro.com', // Replace with your actual support email
        subject: `Customer Support Message - ${authenticated ? 'Dashboard User' : 'Website Visitor'}`,
        message: userMessage,
        timestamp: new Date().toISOString(),
        userType: authenticated ? 'Authenticated User' : 'Website Visitor',
        source: 'Live Chat'
      };

      // Using a simple mailto link as fallback
      const mailtoLink = `mailto:support@investpro.com?subject=${encodeURIComponent(emailData.subject)}&body=${encodeURIComponent(
        `New customer support message:\n\n` +
        `Message: ${userMessage}\n` +
        `User Type: ${emailData.userType}\n` +
        `Source: Live Chat\n` +
        `Timestamp: ${new Date().toLocaleString()}\n\n` +
        `Please respond to this customer inquiry as soon as possible.`
      )}`;

      // For production, you would typically send this to your backend API
      // Example: await fetch('/api/support/message', { method: 'POST', body: JSON.stringify(emailData) });
      
      console.log('Support message logged:', emailData);
      
      // Optional: Open default email client (commented out to avoid popup)
      // window.open(mailtoLink);
      
    } catch (error) {
      console.error('Error sending support message:', error);
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const minimizeChat = () => {
    setIsMinimized(!isMinimized);
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <div className="fixed bottom-6 left-6 z-50">
          <button
            onClick={toggleChat}
            className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 flex items-center gap-3 group"
            title="Live Chat Support"
          >
            <MessageCircle className="h-6 w-6" />
            <span className="hidden group-hover:block whitespace-nowrap bg-blue-700 px-3 py-1 rounded-lg text-sm font-medium absolute left-full ml-3 top-1/2 transform -translate-y-1/2">
              Live Chat
            </span>
          </button>
        </div>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className={`fixed bottom-6 left-6 z-50 bg-white rounded-2xl shadow-2xl border border-slate-200 transition-all duration-300 ${
          isMinimized ? 'w-80 h-16' : 'w-80 h-96'
        }`}>
          {/* Chat Header */}
          <div className="bg-blue-600 text-white p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <Headphones className="h-4 w-4" />
              </div>
              <div>
                <div className="font-semibold text-sm">Customer Support</div>
                <div className="text-blue-200 text-xs">Online • Typically replies instantly</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={minimizeChat}
                className="text-blue-200 hover:text-white transition-colors"
              >
                {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
              </button>
              <button
                onClick={toggleChat}
                className="text-blue-200 hover:text-white transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Chat Body */}
          {!isMinimized && (
            <>
              <div className="h-64 overflow-y-auto p-4 bg-slate-50">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`mb-4 flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className="flex items-start gap-2 max-w-xs">
                      {msg.sender === 'support' && (
                        <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                          <User className="h-3 w-3 text-white" />
                        </div>
                      )}
                      <div
                        className={`px-3 py-2 rounded-lg ${
                          msg.sender === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-white text-slate-800 border border-slate-200'
                        }`}
                      >
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${
                          msg.sender === 'user' ? 'text-blue-200' : 'text-slate-500'
                        }`}>
                          {msg.time}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex justify-start mb-4">
                    <div className="flex items-start gap-2">
                      <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                        <User className="h-3 w-3 text-white" />
                      </div>
                      <div className="bg-white text-slate-800 border border-slate-200 px-3 py-2 rounded-lg">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input */}
              <div className="p-4 border-t border-slate-200 bg-white rounded-b-2xl">
                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors text-sm"
                  />
                  <button
                    type="submit"
                    disabled={!message.trim()}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
};

export default LiveChat;